#ifndef MYSYSLOG_TEXT_H
#define MYSYSLOG_TEXT_H

int log_text(const char* msg, int level, const char* path);

#endif // MYSYSLOG_TEXT_H
