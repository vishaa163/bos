#ifndef MYSYSLOG_JSON_H
#define MYSYSLOG_JSON_H

int log_json(const char* msg, int level, const char* path);

#endif // MYSYSLOG_JSON_H
