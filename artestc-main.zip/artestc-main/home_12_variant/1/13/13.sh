#!/bin/bash

for ((i=1; i<=10; i++))
do 
	result=$((2*i))
	echo "2 * $1" = $result"
done