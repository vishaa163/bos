#!/bin/bash/

du -sh $1