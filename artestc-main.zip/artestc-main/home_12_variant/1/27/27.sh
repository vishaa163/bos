#!/bin/bash

echo -n "Enter unix time: "
read time
date -d@$time