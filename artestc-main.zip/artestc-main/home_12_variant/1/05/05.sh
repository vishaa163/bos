#!/bin/bash

for (( i = 10 ; i > 0 ; i--))
do echo -n "$i "
done
echo 